/**
* this is a car class that deals with the make,year and price of the cars
*
* CSC 1351 Programming Project No 1
7
* Section 2
*
* @author Madyson Barnett
* @since March 17th,2024
*
*/

public class Car implements Comparable<Car> {

// Private members
private String make;
private int year;
private int price;
private int curr;

/**
 * Constructors
 * 
 * @param make the make of the car
 * @param year the year of the car
 * @param price the price of the car
*/

public Car(String make, int year, int price) {
	
	this.make = make;
	this.year = year;
	this.price = price;

}	

/* Getter (public) methods
 * 
 * returns the make, year and price of the cars
 */

public String getMake() {
	return make;
}
public int getYear() {
	return year;
}
public int getPrice() {
	return price;
}

//Comparison method 
//it compares the price of the the cars and if the prices are different its prints the results

public int compareTo(Car other) {
	
	if(Integer.compare(price,other.price)!=0)
		return Integer.compare(price, other.price);
	else 
		return Integer.compare(year, other.year);
}
	
@Override
public String toString() {
	return "Make: " + make + ", Year: " + year + " , Price: " + price + ";";
}
public void add(Comparable newObject) {
}
public Comparable get(int index) {
	return null;
}
}

